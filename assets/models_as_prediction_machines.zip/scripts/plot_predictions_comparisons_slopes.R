## -----------------------------------------------------------------------------
source(here::here("scripts/load.R"))


## ----load_fit-----------------------------------------------------------------

source(here::here("scripts/load.R"))

# We analyze freely available practice data from the German Socio-Econmic Panel Study (SOEP).
# The data can be downloaded from the SOEP website (https://www.diw.de/en/diw_01.c.836543.en/soep_practice_dataset.html);
# We are using the English version (DOI: 10.5684/soep.practice.v36).

# Read data
soep <- read_dta(here("data/practice_en/practice_dataset_eng.dta"))
head(soep)

# Fit simple model that predicts life satisfaction
mod <- lm(
  lebensz_org ~ sex * bs(alter, df = 3) * bs(einkommenj1, df = 3),
  data = soep[soep$alter < 60, ]
)
# this model is fairly flexible insofar that it flexibly models the effects of age and income
# and also allows for all interactions between the variables
# we limit ourselves to people under the age of 60


# let's take a look at the coefficients to confirm they are not easily interpretable
summary(mod)


## ----interpretation-----------------------------------------------------------

# Prediction: life satisfaction of a 35 year old woman who earns 20,000 euro
predictions(mod, newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 20000))

# Store value for plotting purposes
prediction_20000 <- predictions(
  mod,
  newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 20000)
)$estimate


# Prediction: what if she earned twice as much?
predictions(mod, newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 40000))

# Store value for plotting purposes
prediction_40000 <- predictions(
  mod,
  newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 40000)
)$estimate


# Comparison: Compare these two predictions
comparisons(
  mod,
  newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 20000),
  variables = list("einkommenj1" = c(20000, 40000))
)


# Slope: How much does life satisfaction increase with income at 20000 euro
slopes(
  mod,
  newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 20000),
  variables = "einkommenj1"
)

# Store value for plotting
slope_20000 <- slopes(
  mod,
  newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 20000),
  variables = "einkommenj1"
)$estimate

# Let's translate this into life satisfaction points per 1,000 Euro
slopes(
  mod,
  newdata = data.frame(sex = 1, alter = 35, einkommenj1 = 20000),
  variables = "einkommenj1"
)$estimate *
  1000


## ----figure-------------------------------------------------------------------

# We *could* directly do this with the help of marginaleffects using the following:
plot_predictions(
  mod,
  newdata = data.frame(
    sex = 1,
    alter = 35,
    einkommenj1 = seq(from = 0, to = 80000, by = 10)
  ),
  by = "einkommenj1"
)

# However, let's take things slowly and do this manually
# Just for ease of plot-optimization

# First step: Generate a data frame containing the same 35-year-old woman under different incomes
hypothetical_woman <- data.frame(
  sex = 1,
  alter = 35,
  einkommenj1 = seq(from = 0, to = 80000, by = 10)
)

# Let's generate her life satisfactions (predicted life satisfaction)
hypothetical_predictions <- predictions(mod, newdata = hypothetical_woman)
head(hypothetical_predictions)

# Add the life satisfaction to the data we are going to plot
hypothetical_woman$lebensz_org <- hypothetical_predictions$estimate


# Let's plot!

# Just for customization: x-axis range over which the slope should be plotted
slope_range <- c(0, 60000)

# Color scheme
color_prediction <- "#0072B2"
color_comparison <- "#56B4E9"
color_slope <- "#009E73"
color_neutral <- "#BBBBBB"


ggplot(data = hypothetical_woman, aes(x = einkommenj1, y = lebensz_org)) +
  # Prediction line
  geom_line() +
  # Comparison 20,000 vs 40,000 (connected with  segments that form a slope triangle)
  geom_segment(
    x = 20000,
    xend = 40000,
    y = prediction_20000,
    color = color_neutral,
    linetype = "dashed"
  ) +
  geom_segment(
    x = 40000,
    y = prediction_20000,
    yend = prediction_40000,
    color = color_comparison,
    linetype = "solid"
  ) +
  # Slope line at an income of 20,000
  geom_segment(
    x = slope_range[1],
    xend = slope_range[2],
    y = prediction_20000 - (20000 - slope_range[1]) * slope_20000,
    yend = prediction_20000 + (slope_range[2] - 20000) * slope_20000,
    color = color_slope
  ) +
  # Predictions at 20,000 and 40,000
  geom_point(x = 20000, y = prediction_20000, color = color_prediction) +
  geom_point(x = 40000, y = prediction_40000, color = color_prediction) +
  # Layout, make it look nicer
  xlab("Annual gross income") +
  ylab("Predicted life satisfaction") +
  coord_cartesian(ylim = c(7, 8.25)) +
  scale_x_continuous(
    labels = label_dollar(prefix = "", suffix = "€", big.mark = ",")
  )

ggsave(here("plots/predictions_comparisons_slopes.png"), width = 4, height = 3)



