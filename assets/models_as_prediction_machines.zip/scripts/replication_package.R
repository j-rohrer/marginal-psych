# Generate replication package

# Wait until all analyses are set in stone

# library(knitr)
# purl("notebooks/relationship_friends.qmd", output = "scripts/worked_example_1.R")
# purl("notebooks/deskmates.qmd", output = "scripts/worked_example_2.R")

# Note: remove references to here() manually
# Add the loading to the front of the script 
# so there is no need for a separate load script in the replication package


# bundle up: 
# data folder with the data for examples
# worked_example scripts
# README.txt
