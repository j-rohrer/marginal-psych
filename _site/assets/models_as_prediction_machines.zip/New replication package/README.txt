Replication package to accompany

“Models as Prediction Machines: How to Convert Confusing Coefficients into Clear Quantities” by Julia M. Rohrer and Vincent Arel-Bundock (2025)

Website:
https://j-rohrer.github.io/marginal-psych/

Contact:
julia.rohrer@uni-leipzig.de

Contents of the package:

data/ contains the data underlying the two worked examples
deskmates.csv (Worked Example 2)
start.csv (Worked Example 1)

examples/ contains the Quarto scripts containing the analysis code
deskmates.qmd (Worked Example 2)
relationship.qmd (Worked Example 1)
soep.qmd (Illustrating various target quantities, see Figure 1 in the manuscript)

fits/ pre-fitted brms models
deskmates.rds (Worked Example 2)
relationships_ordinal_brm.rds (Bayesian ordinal robustness check)


scripts/ additional scripts
load.R (loads necessary packages)
plot_logit_scale.R (creates Figure 2 in the manuscript)